"""
**********************************************
name    : downloader
author  : ZSAIm
version : 0.1
email   : 405935987@163.com
GitHub  : https://github.com/ZSAIm/downloader
**********************************************
                                Python  : 2.7
"""

from downloader import *